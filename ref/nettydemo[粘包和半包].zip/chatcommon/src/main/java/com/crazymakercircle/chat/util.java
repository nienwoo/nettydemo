package com.crazymakercircle.chat;

public class util
{

    public  static  String[]  split(String s)
    {
       return s.split("\\s+->\\s+");
    }


}
